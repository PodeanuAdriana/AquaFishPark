
package acvariu_de_pesti;


public class Peste {
    String nume;
    float niv_sanatate;
    int niv_foame;
    public Peste(String name){
        this.nume=name;
        this.niv_foame=0;
        this.niv_sanatate=50.0f;
    }
    public void feed(){
    niv_foame= niv_foame-5;
    System.out.println(nume+"a fost hranit!");
}
    public void moarePeste(){
        niv_foame=Math.min(10, niv_foame+1);
        if(niv_foame > 8)
            niv_sanatate--;
    }
    public boolean Traieste(){
        return niv_sanatate > 0;
    }
    
    public String afisare(){
        return nume + " Foame: "+niv_foame+" /10 | Sanatate: " +niv_sanatate+"/ 50.0";
        
    }
    
}



