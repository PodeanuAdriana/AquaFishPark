
package acvariu_de_pesti;
import java.util.*;

public class Acvariu_de_pesti {

  
    public static void main(String[] args) {
        Acvariu acv = new Acvariu();
        Scanner scan = new Scanner(System.in);
        String optiune;
        
        System.out.println("Acesta este AquaFishPark!");
        
//        System.out.println("Selecteaza o optiune!");
        
        do{
            System.out.println("Selecteaza o optiune!");
            System.out.println("1.Adauga pestisor!");
            System.out.println("2.Hraneste pestisorii!");
//            System.out.println("3.Curata acvariul!");
            System.out.println("3.Adauga apa!");
            System.out.println("4.Afisare parametrii!");
            System.out.println("0.Iesire");
             System.out.print(">> ");
             optiune=scan.nextLine();
            switch(optiune){
                case "1":{
                    System.out.print("Nume pește: ");
                    String name = scan.nextLine();
                    Acvariu.adaugaPestisori(name);
                    break;
                }
                case "2":
                {
                    Acvariu.hranirePestisori();
                    break;
                }
                case "3":
                { Acvariu.adaugApa();
                    break;
                }
                case "4":
                {
                    Acvariu.afisareParam();
                    break;
                }
            }
        }while(!optiune.equals("0"));
        scan.close();
        
    }
    
}
