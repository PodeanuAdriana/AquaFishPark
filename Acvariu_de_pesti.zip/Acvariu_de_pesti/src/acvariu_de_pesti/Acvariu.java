
package acvariu_de_pesti;
import java.util.ArrayList;
  

public class Acvariu {
      private static ArrayList<Peste> pesti;
      private static int murdarie;// de la 0 (curat) la 10 (infect)
      private static int niv_apa;// de la 0 la 5 l
      
      public Acvariu(){
          pesti= new ArrayList<>();
          murdarie=0;
          niv_apa=5;
      }
      
      public static void adaugApa(){
          if(niv_apa <= 3)
              niv_apa=Math.min(5,5-niv_apa);
          System.out.println("Ai adaugat apa in acvariu: " + niv_apa);
      }
      public static void adaugaPestisori(String nume){
          pesti.add(new Peste(nume));
          niv_apa--;
//adaugare peste in acvariu prin intermediul apelarii clasei
          System.out.println("Ai adaugat pestele: "+nume);
      }
      
      public  static void hranirePestisori(){
          //iau fiecare pestisor din acvariu
          for (Peste p : pesti){
              if(p.Traieste() && p.niv_foame > 4)
                  p.feed();
          }
          murdarie=Math.min(10,murdarie+1);
      }
      
      public static void afisareParam(){
            System.out.println("Status acvariu:");
        for (Peste p : pesti) {
            System.out.println(" - " + p);
        }
        System.out.println(" Nivel murdărie apă: " + murdarie + "/10");
        System.out.println(" Nivel  apă: " + niv_apa + "/5");
        
      }
}
